package TP07.ex2;

public enum Type{
    TEXT,MMS
}