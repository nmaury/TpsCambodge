package TP10.ex3;

public enum Status {
    WAITING_TO_ORDER,ORDERING,WAITING_FOR_FOOD,SERVED
}
