package TP09.ex3;

public enum CategoryBook {
    MATH,JAVA,OTHER,FOOTBALL,BEAUTY,FAIRYTALE
}
