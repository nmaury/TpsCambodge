package TP09.ex3;

public class PublishedDateException extends RuntimeException{
    public PublishedDateException(String message) {
        super(message);
    }
}
