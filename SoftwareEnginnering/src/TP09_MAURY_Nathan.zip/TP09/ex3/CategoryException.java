package TP09.ex3;

public class CategoryException extends RuntimeException{
    public CategoryException(String message) {
        super(message);
    }
}
