package TP09.ex3;

public class StringTooLongException extends RuntimeException{
    public StringTooLongException(String message) {
        super(message);
    }
}
