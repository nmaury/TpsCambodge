package TP09.ex1;

public class BirthDateException extends RuntimeException{
    public BirthDateException(String message) {
        super(message);
    }
}
