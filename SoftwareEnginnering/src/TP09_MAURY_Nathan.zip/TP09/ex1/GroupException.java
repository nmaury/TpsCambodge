package TP09.ex1;

public class GroupException extends RuntimeException{
    public GroupException(String message) {
        super(message);
    }
}
