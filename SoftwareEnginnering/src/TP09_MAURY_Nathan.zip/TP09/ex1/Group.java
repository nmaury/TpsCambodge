package TP09.ex1;

public enum Group {
    A,B,C,D
}
