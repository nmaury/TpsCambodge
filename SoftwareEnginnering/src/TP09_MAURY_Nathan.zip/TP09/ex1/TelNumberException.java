package TP09.ex1;

public class TelNumberException extends RuntimeException{
    public TelNumberException(String message) {
        super(message);
    }
}
